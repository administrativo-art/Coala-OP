# Evidências de validação externa — 25/10/2026

Pacote arquivado após validação no VALIDAR/ITI. As amostras são sintéticas e permanecem sem validade operacional, conforme a documentação de homologação.

## AFD/CAdES

| Arquivo | SHA-256 | Resultado |
| --- | --- | --- |
| `AMOSTRA_AFD0000000000000000011222333000181REP_P-v2.txt` | `c2bc27a3ec2eca748036fd96cfb1bcd944191be42d0c6a028c8cf3eccdc52c77` | Arquivo original |
| `AMOSTRA_AFD0000000000000000011222333000181REP_P-v2.txt.p7s` | `73c6a8192fb81e7f03abfa2201d2107af0ac42309c60d5aa3c29a0b55d97120d` | Assinatura destacada aprovada |
| `Relatorio - AMOSTRA_AFD0000000000000000011222333000181REP_P-v27s.pdf` | `ce26988dd7dae48041405987a272584e6f7c376e354f8c164f82fb93c02318fd` | VALIDAR/ITI: aprovado |

O relatório confirma: caminho de certificação aprovado, estrutura em conformidade, resumo criptográfico verdadeiro, atributos obrigatórios aprovados e nenhum alerta.

## Comprovante/PAdES

| Arquivo | SHA-256 | Resultado |
| --- | --- | --- |
| `Relatorio - AMOSTRA_comprovante-ponto-2026-10-25-nsr-3.pdf` | `04a4e652b7f12599a8a570745c1f2f0f3cf21b981f5d7b58249450c29d50f084` | VALIDAR/ITI: aprovado |

## Observação

O relatório de validação do e-CPF não foi localizado na pasta Downloads nesta sessão e, por isso, não foi incluído neste pacote. Não se substitui essa evidência por outro arquivo.
